outp = ["Yes","No","Maybye"]
print ("============")
print ("Truth teller")
print ("============")
print (" ")
import random
while True:
  ans = input("Ask me anything, and I will anser")
  print (random.choice(outp))